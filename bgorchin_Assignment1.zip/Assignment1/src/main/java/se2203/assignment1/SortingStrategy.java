package se2203.assignment1;

public interface SortingStrategy extends Runnable {

    // sort method
    public void sort(int arr[], int l, int r);
}
